const createProduct = (data) => {
	let productContainer = document.querySelector('.product-container');
	productContainer.innerHTML += `
	<div class="product-card">
		<button class="btn edit-btn"><img src="E:/web/online/fullstack/lecture1/public/img/edit.png"></button>
		<button class="btn open-btn"><img src="E:/web/online/fullstack/lecture1/public/img/open.png"></button>
		<button class="btn delete-btn"><img src="E:/web/online/fullstack/lecture1/public/img/delete.png"></button>
		<img src="E:/web/online/fullstack/lecture1/public/img/product-1.jpg" class="product-img" alt="">
    	<p class="product-name">Lights</p>
	</div>
            `;
}

const deleteItem = (id) => {
	fetch('/delete-product', {
		method: 'post',
		headers: new Headers({'Content-Type' : 'application/json'}),
		body: JSON.stringify({id: id})

	}).then(res => res.json())
	.then(data => {
		//process data
		if (data == 'success'){
			location.reload();
		}
		else{
			showAlert('some error occurred');
		}
	})
}