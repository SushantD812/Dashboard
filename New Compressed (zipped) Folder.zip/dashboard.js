let user = JSON.parse(sessionStorage.user || null)

if(user == null){
	location.replace('E:/web/online/fullstack/lecture1/public/login.html')

}else if {
	location.replace('E:/web/online/fullstack/lecture1/public/seller.html')
}
let greeting = document.querySelector('#seller-greeting');
greeting.innerHTML += user.name;


//loader
let loader = document.querySelector('.loader');
let noProductImg = document.querySelector('.no-product');

loader.style.display = 'block';

const setupProduct = () => {
	fetch('/get-products', {
		method: 'post',
		headers: new Headers({'Content-Type':'application/json'}),
		body: JSON.stringify({email : user.email})
	})

	.then(res => res.json())
	.then(data => {
		loader.style.display = 'none';
		if(data == 'no-product'){
			noProductImg.style.display = 'block';
		}
		else{
			data.forEach(product => createProduct(product));
		}
	})
}

setupProducts();