window.onload = () => {
	let user = JSON.parse(sessionStorage.user || null);

	if(user == null){
		location.replace('E:/web/online/fullstack/lecture1/public/login.html');
	} else if(user.seller){
		location.replace('E:/web/online/fullstack/lecture1/public/dashboard.html');
	}
}
let loader = document.querySelector('.loader');
let applyBtn = document.querySelector('.apply-btn');

applyBtn.addEventListener('click', () => {
	// alert('clicked');
	let businessName = document.querySelector('#name').value;
	let address = document.querySelector('#address').value;
	let about = document.querySelector('#about').value;
	let number = document.querySelector('#number').value;


	// if (!businessName.length || !address.length || !about.length ||number.length <10 || !Number(number)){
	// 	// alert('error')
	// 	showFormError('some information(s) is/are incorrect');
	// }else{
		//send data
		loader.style.display = 'block';
		sendData('E:/web/online/fullstack/lecture1/public/seller.html', {
			name: businessName,
			address: address,
			about: about,
			number: number,
			email: JSON.parse(sessionStorage.user).email
		})
	//}


})