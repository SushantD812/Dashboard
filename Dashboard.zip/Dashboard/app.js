const Task = require("./models/task")

const app = express()
app.use(express.urlencoded({extended: true}))

const db_uri = "ENTER YOUR MONGODB URL HERE"

mongoose.connect(db_uri).then(()=> {
    app.listen(3000)
    console.log("db connected")

}).catch((err)=>{
    console.log(err)
})

app.use(express.static('public'));
app.set("view engine", "ejs")

app.use(express.json()); 

const session = require('express-session');
app.use(session({secret: 'some secret code', resave: false, saveUninitialized:true}));

//-----------------------------------------------------------------------------------------------


app.get("/", (req,res)=>{
    res.redirect('/dashboard')
})

//DASH
app.get('/dashboard', (req,res)=>{
    Task.find({status:"Completed"}).then((result_completed)=>{
        Task.find({status:"Pending"}).then((result_pending)=>{
        
            res.render("dashboard", {
                title: "Dashboard",
                completedTasks: result_completed,
                pendingTasks: result_pending
            })

        }).catch((err)=>{
            console.log(err)
        })
        
    }).catch((err)=>{
        console.log(err)
    })
})

app.post('/updateTask', (req,res)=>{
    let task_id = {'_id':req.body.taskID}
    let setStatus = { $set: {status: "Completed"} };
    Task.updateOne(task_id, setStatus).then((result)=>{
        res.redirect('/dashboard') 
        console.log("Record status updated")
    }).catch((err)=>{
        console.log(err)
    })
})